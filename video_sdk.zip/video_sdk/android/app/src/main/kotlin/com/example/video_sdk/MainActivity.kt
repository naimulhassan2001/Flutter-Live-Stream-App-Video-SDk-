package com.example.video_sdk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
